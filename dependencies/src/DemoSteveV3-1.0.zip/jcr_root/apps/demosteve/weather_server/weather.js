


use(function () {


    //get JSON OSGi Service
    var jsonService = sling.getService(Packages.com.ags.weather.core.services.JSONService);


    
   var CONST = {
       PROP_ZIPCODE: "zipcode",
    }
    

    var weather = {};


    // Adding the constants to the exposed API

       var zipcode = granite.resource.properties[CONST.PROP_ZIPCODE];
    
    if(zipcode!=null){
        
        //get JSON from openweathermap
        var jsonResponse = jsonService.getJSONFromURL('http://api.openweathermap.org/data/2.5/weather?appid=564c86638eac5dea6c20891a56a41279&units=imperial&zip='+zipcode);
        var weatherJSON = JSON.parse(jsonResponse);

        //get temp from JSON response
        var temp = weatherJSON.main.temp;  
        var city = weatherJSON.name

        weather.temp= temp +"F";
        weather.city= city;

    }



    return weather;
    
});
