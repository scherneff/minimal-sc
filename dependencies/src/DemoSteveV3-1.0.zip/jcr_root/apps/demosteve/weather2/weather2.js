
 window.onload = function() {
   getweather();
 };

function getweather() {
    var myChData = JSON.parse(window.localStorage.getItem('ContextHubPersistence'));
    var myZip = myChData.store.geolocation.address.postalCode;
    var aemZip = zipcode.getAttribute('value');
    console.log("AEM Authored Zip = "+aemZip);
    console.log("Geolocaton Zip = "+myZip);
    xmlhttp = new XMLHttpRequest(); 
    if( aemZip!== null){
        var url = "https://api.openweathermap.org/data/2.5/weather?appid=564c86638eac5dea6c20891a56a41279&units=imperial&zip=" + aemZip;
    } else{
        var url = "https://api.openweathermap.org/data/2.5/weather?appid=564c86638eac5dea6c20891a56a41279&units=imperial&zip=" + myZip;
    }
    xmlhttp.open('GET', url, true);
    xmlhttp.send(null);
    xmlhttp.onreadystatechange = function() {
        if (xmlhttp.readyState == 4) {
            if (xmlhttp.status == 200) {
                var myweather = JSON.parse(xmlhttp.response);
                var city = myweather.name;
                var conditions = myweather.weather[0].main;
                var description = myweather.weather[0].description
                var temp = Math.round(myweather.main.temp) + "°F";
                console.log(myweather.weather[0].main)
                document.getElementById('city').innerHTML = city
                document.getElementById('description').innerHTML = description
                document.getElementById('temp').innerHTML = temp
                
                switch (conditions) {
                    case 'Clouds':  document.getElementById('cloudy').style.display = "grid";
                    break;
                 
                    case 'Rain':document.getElementById('rain').style.display = "grid";
                    break;
                 
                    case 'Clear':document.getElementById('clear').style.display = "grid";
                    break;
                 
                    case 'Snow':document.getElementById('snow').style.display = "grid";
                    break;
                   
                    default:  document.getElementById('clear').style.display = "grid";
                 }

            } else
                alert("Error ->" + xmlhttp.responseText);
        }
    }

}